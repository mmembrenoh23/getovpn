-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table getovpn_db.error_logs
DROP TABLE IF EXISTS `error_logs`;
CREATE TABLE IF NOT EXISTS `error_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `window` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `thrown_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.error_logs: ~0 rows (approximately)
/*!40000 ALTER TABLE `error_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `error_logs` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.jobs
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.jobs: ~4 rows (approximately)
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
	(1, 'processing', '{"uuid":"f841fb5b-1bd6-4591-8eff-646214040b7d","displayName":"App\\\\Jobs\\\\LogsApplication","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"delay":null,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\LogsApplication","command":"O:24:\\"App\\\\Jobs\\\\LogsApplication\\":12:{s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_window\\";s:17:\\"ServersController\\";s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_action\\";s:10:\\"index-show\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_message\\";s:33:\\"Get all directories from database\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_user_id\\";i:2;s:3:\\"job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";s:10:\\"processing\\";s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}}"}}', 0, NULL, 1612330988, 1612330988),
	(2, 'processing', '{"uuid":"42714e99-2513-4507-8eea-a4d5fa683248","displayName":"App\\\\Jobs\\\\LogsApplication","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"delay":null,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\LogsApplication","command":"O:24:\\"App\\\\Jobs\\\\LogsApplication\\":12:{s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_window\\";s:17:\\"ServersController\\";s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_action\\";s:10:\\"index-show\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_message\\";s:33:\\"Get all directories from database\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_user_id\\";i:2;s:3:\\"job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";s:10:\\"processing\\";s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}}"}}', 0, NULL, 1612331258, 1612331258),
	(4, 'processing', '{"uuid":"a1008f97-cf4a-46ab-a9b6-6b5bc1487c67","displayName":"App\\\\Jobs\\\\LogsApplication","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"delay":null,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\LogsApplication","command":"O:24:\\"App\\\\Jobs\\\\LogsApplication\\":12:{s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_window\\";s:17:\\"ServersController\\";s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_action\\";s:10:\\"index-show\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_message\\";s:33:\\"Get all directories from database\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_user_id\\";i:2;s:3:\\"job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";s:10:\\"processing\\";s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}}"}}', 0, NULL, 1612331370, 1612331370),
	(5, 'processing', '{"uuid":"93c287af-bc33-4a19-b9fa-fbcb9ec08342","displayName":"App\\\\Jobs\\\\LogsApplication","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"delay":null,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\LogsApplication","command":"O:24:\\"App\\\\Jobs\\\\LogsApplication\\":12:{s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_window\\";s:17:\\"ServersController\\";s:33:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_action\\";s:10:\\"index-show\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_message\\";s:33:\\"Get all directories from database\\";s:34:\\"\\u0000App\\\\Jobs\\\\LogsApplication\\u0000_user_id\\";i:2;s:3:\\"job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";s:10:\\"processing\\";s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}}"}}', 0, NULL, 1612331413, 1612331413);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.logs_app
DROP TABLE IF EXISTS `logs_app`;
CREATE TABLE IF NOT EXISTS `logs_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `window` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logs_app_user_id_foreign` (`user_id`),
  CONSTRAINT `logs_app_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.logs_app: ~23 rows (approximately)
/*!40000 ALTER TABLE `logs_app` DISABLE KEYS */;
INSERT INTO `logs_app` (`id`, `window`, `action`, `message`, `user_id`, `created_at`, `updated_at`) VALUES
	(1, 'ServersController', 'index-show', 'Get all directories from database', 2, '2021-02-03 05:48:27', '2021-02-03 05:48:27'),
	(2, 'ServersController', 'index-show', 'Get all directories from database', 2, '2021-02-03 05:50:58', '2021-02-03 05:50:58'),
	(3, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-03 05:56:02', '2021-02-03 05:56:02'),
	(4, 'ServersController', 'index-show', 'Use of undefined constant s - assumed \'s\' (this will throw an Error in a future version of PHP)', 2, '2021-02-03 06:07:46', '2021-02-03 06:07:46'),
	(5, 'ServersController', 'index-show', 'a:3:{s:4:"line";i:31;s:4:"file";s:70:"C:\\laravel_projects\\getovpn\\app\\Http\\Controllers\\ServersController.php";s:7:"message";s:95:"Use of undefined constant s - assumed \'s\' (this will throw an Error in a future version of PHP)";}', 2, '2021-02-03 06:12:29', '2021-02-03 06:12:29'),
	(6, 'ServersController', 'index-show', 'a:3:{s:4:"line";i:31;s:4:"file";s:70:"C:\\laravel_projects\\getovpn\\app\\Http\\Controllers\\ServersController.php";s:7:"message";s:95:"Use of undefined constant s - assumed \'s\' (this will throw an Error in a future version of PHP)";}', 2, '2021-02-04 17:33:56', '2021-02-04 17:33:56'),
	(7, 'ServersController', 'index-show', 'Get all directories from database', 2, '2021-02-04 17:33:56', '2021-02-04 17:33:56'),
	(8, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-04 17:33:56', '2021-02-04 17:33:56'),
	(9, 'ServersController', 'index-show', 'Get all directories from database', 2, '2021-02-04 17:33:56', '2021-02-04 17:33:56'),
	(10, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-04 17:33:56', '2021-02-04 17:33:56'),
	(11, 'ServersController', 'getDownloadFile -> copyFiletoDownload', 'Download File: VOIP_jgutierrez - Copy (2) ', 2, '2021-02-04 19:41:36', '2021-02-04 19:41:36'),
	(12, 'ServersController', 'index-show', 'Get all directories from database', 2, '2021-02-04 19:44:31', '2021-02-04 19:44:31'),
	(13, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-04 19:44:34', '2021-02-04 19:44:34'),
	(14, 'ServersController', 'getDownloadFile -> copyFiletoDownload', 'Download File: VOIP_jgutierrez - Copy (2) ', 2, '2021-02-04 19:44:37', '2021-02-04 19:44:37'),
	(15, 'ServersController', 'generateLink', 'Link to download file was generated. http://localhost:8000/voip-file/%242y%2410%24RKffGYKbr8EYKlbd1WUMU.F7T2CvCgXuGsaKhV.Rn3avdd9PpEkKC', 2, '2021-02-04 19:48:47', '2021-02-04 19:48:47'),
	(16, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-04 19:57:09', '2021-02-04 19:57:09'),
	(17, 'ServersController', 'getDownloadFile', 'a:3:{s:4:"line";i:68;s:4:"file";s:90:"C:\\laravel_projects\\getovpn\\vendor\\laravel\\framework\\src\\Illuminate\\Routing\\Controller.php";s:7:"message";s:68:"Method App\\Http\\Controllers\\ServersController::getIp does not exist.";}', 2, '2021-02-04 19:57:13', '2021-02-04 19:57:13'),
	(18, 'ServersController', 'getDownloadFile -> copyFiletoDownload', 'Download File: VOIP_jgutierrez - Copy (2) ', 2, '2021-02-04 19:57:31', '2021-02-04 19:57:31'),
	(19, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-04 19:57:43', '2021-02-04 19:57:43'),
	(20, 'ServersController', 'getDownloadFile -> copyFiletoDownload', 'Download File: VOIP_jgutierrez - Copy (3) ', 2, '2021-02-04 19:57:43', '2021-02-04 19:57:43'),
	(21, 'ServersController', 'getDownloadFile -> copyFiletoDownload', 'Download File: VOIP_jgutierrez - Copy (3) ', 2, '2021-02-04 19:57:55', '2021-02-04 19:57:55'),
	(22, 'ServersController', 'getDownloadFile -> copyFiletoDownload', 'Download File: VOIP_jgutierrez - Copy (4) ', 2, '2021-02-04 19:59:28', '2021-02-04 19:59:28'),
	(23, 'ServersController', 'index-show', 'Get all directories from database', 2, '2021-02-04 20:05:06', '2021-02-04 20:05:06'),
	(24, 'ServersController', 'getServerFiles', 'get server files (Server 1). Total Files 10', 2, '2021-02-04 20:05:12', '2021-02-04 20:05:12');
/*!40000 ALTER TABLE `logs_app` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.logs_download_file
DROP TABLE IF EXISTS `logs_download_file`;
CREATE TABLE IF NOT EXISTS `logs_download_file` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `OS` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `browser` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `server_file_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logs_download_file_server_file_id_foreign` (`server_file_id`),
  CONSTRAINT `logs_download_file_server_file_id_foreign` FOREIGN KEY (`server_file_id`) REFERENCES `server_file` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.logs_download_file: ~4 rows (approximately)
/*!40000 ALTER TABLE `logs_download_file` DISABLE KEYS */;
INSERT INTO `logs_download_file` (`id`, `is_admin`, `OS`, `browser`, `device`, `ip`, `server_file_id`, `created_at`, `updated_at`) VALUES
	(1, 0, 'Windows 10', 'Chrome 88.0.4324', 'Desktop', '127.0.0.1', 1, '2021-02-04 19:56:27', '2021-02-04 19:56:27'),
	(2, 1, 'Windows 10', 'Chrome 88.0.4324', 'Desktop', '127.0.0.1', 1, '2021-02-04 19:57:31', '2021-02-04 19:57:31'),
	(3, 1, 'Windows 10', 'Chrome 88.0.4324', 'Desktop', '127.0.0.1', 2, '2021-02-04 19:57:43', '2021-02-04 19:57:43'),
	(4, 1, 'Windows 10', 'Chrome 88.0.4324', 'Desktop', '127.0.0.1', 2, '2021-02-04 19:57:55', '2021-02-04 19:57:55'),
	(5, 1, 'Windows 10', 'Chrome 88.0.4324', 'Desktop', '127.0.0.1', 3, '2021-02-04 19:59:28', '2021-02-04 19:59:28');
/*!40000 ALTER TABLE `logs_download_file` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.log_file_user
DROP TABLE IF EXISTS `log_file_user`;
CREATE TABLE IF NOT EXISTS `log_file_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `logs_download_file_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_file_user_logs_download_file_id_foreign` (`logs_download_file_id`),
  KEY `log_file_user_user_id_foreign` (`user_id`),
  CONSTRAINT `log_file_user_logs_download_file_id_foreign` FOREIGN KEY (`logs_download_file_id`) REFERENCES `logs_download_file` (`id`),
  CONSTRAINT `log_file_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.log_file_user: ~4 rows (approximately)
/*!40000 ALTER TABLE `log_file_user` DISABLE KEYS */;
INSERT INTO `log_file_user` (`id`, `logs_download_file_id`, `user_id`, `created_at`, `updated_at`) VALUES
	(1, 2, 2, '2021-02-04 19:57:31', NULL),
	(2, 3, 2, '2021-02-04 19:57:43', NULL),
	(3, 4, 2, '2021-02-04 19:57:55', NULL),
	(4, 5, 2, '2021-02-04 19:59:28', NULL);
/*!40000 ALTER TABLE `log_file_user` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.migrations: ~9 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2021_01_20_025311_create_users_table', 1),
	(2, '2021_01_20_055159_create_servers_table', 2),
	(3, '2021_01_20_052528_create_server_file_table', 3),
	(4, '2021_01_20_055426_create_logs_download_file_table', 3),
	(5, '2021_01_20_055439_create_logs_app_table', 3),
	(6, '2021_01_20_060820_create_user_attemps_table', 3),
	(7, '2021_01_20_061016_create_error_logs_table', 3),
	(8, '2021_01_22_025136_create_jobs_table', 4),
	(9, '2021_02_04_181744_create_log_file_user_table', 5),
	(12, '2021_02_04_185151_add_browser_device_os_field', 6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.servers
DROP TABLE IF EXISTS `servers`;
CREATE TABLE IF NOT EXISTS `servers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `server_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.servers: ~8 rows (approximately)
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` (`id`, `path`, `server_name`, `created_at`, `updated_at`) VALUES
	(17, 'C:\\Server\\Server 1', 'Server 1', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(18, 'C:\\Server\\Server 1 - Copy', 'Server 1 - Copy', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(19, 'C:\\Server\\Server 1 - Copy (2)', 'Server 1 - Copy (2)', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(20, 'C:\\Server\\Server 1 - Copy (3)', 'Server 1 - Copy (3)', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(21, 'C:\\Server\\Server 1 - Copy (4)', 'Server 1 - Copy (4)', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(22, 'C:\\Server\\Server 1 - Copy (5)', 'Server 1 - Copy (5)', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(23, 'C:\\Server\\Server 1 - Copy (6)', 'Server 1 - Copy (6)', '2021-01-22 03:34:13', '2021-01-22 03:34:13'),
	(24, 'C:\\Server\\Server 1 - Copy (7)', 'Server 1 - Copy (7)', '2021-01-22 03:34:13', '2021-01-22 03:34:13');
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.server_file
DROP TABLE IF EXISTS `server_file`;
CREATE TABLE IF NOT EXISTS `server_file` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_file` date NOT NULL,
  `size` decimal(8,2) DEFAULT NULL,
  `url_download` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `server_file_server_id_foreign` (`server_id`),
  CONSTRAINT `server_file_server_id_foreign` FOREIGN KEY (`server_id`) REFERENCES `servers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.server_file: ~9 rows (approximately)
/*!40000 ALTER TABLE `server_file` DISABLE KEYS */;
INSERT INTO `server_file` (`id`, `path`, `name`, `owner`, `created_file`, `size`, `url_download`, `secret`, `server_id`, `created_at`, `updated_at`) VALUES
	(1, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (2).txt', 'VOIP_jgutierrez - Copy (2)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24RKffGYKbr8EYKlbd1WUMU.F7T2CvCgXuGsaKhV.Rn3avdd9PpEkKC', '$2y$10$RKffGYKbr8EYKlbd1WUMU.F7T2CvCgXuGsaKhV.Rn3avdd9PpEkKC', 17, '2021-01-22 03:44:27', '2021-02-02 00:06:56'),
	(2, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (3).txt', 'VOIP_jgutierrez - Copy (3)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24Dof6DVv6VX3.936wx5Qe5.wUOt2JgIc7rdGI/Kko53CfjPHRvPV76', '$2y$10$1ArsDA3DiflNIPazM0iYqOUeyOigOkcL0TbBrQvXI7wdjVxUr0Uta', 17, '2021-01-22 03:44:27', '2021-01-29 17:42:44'),
	(3, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (4).txt', 'VOIP_jgutierrez - Copy (4)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24VzHRvOX/SaVXTzJ2G7dvUOtDBiU4xdckvYs6bowqGhUInP8ns265q', '$2y$10$VzHRvOX/SaVXTzJ2G7dvUOtDBiU4xdckvYs6bowqGhUInP8ns265q', 17, '2021-01-22 03:44:27', '2021-01-29 06:48:51'),
	(4, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (5).txt', 'VOIP_jgutierrez - Copy (5)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24wJfhT98hE3bV0pDRWiq4u.OeN.KVyVvxg64YeP0nQRJMN9nJPxkBq', '$2y$10$NIg.OT/jGKbuGq/4RfPKN.K0miGiZY/JSOQ1fi6QkHsFNfNYxESEG', 17, '2021-01-22 03:44:27', '2021-01-29 21:09:59'),
	(5, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (6).txt', 'VOIP_jgutierrez - Copy (6)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24KdTGN/myS5aENL3gIor9IuovoyWuxRv1a5qoVvV0FwB/Zu9LHcKCy', '$2y$10$KdTGN/myS5aENL3gIor9IuovoyWuxRv1a5qoVvV0FwB/Zu9LHcKCy', 17, '2021-01-22 03:44:28', '2021-01-29 06:51:23'),
	(6, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (7).txt', 'VOIP_jgutierrez - Copy (7)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24Ids.Ivt6BADjSHyCOcbNseUgeFmiOAF3hOV3oIOkexaTZ300TqH/2', '$2y$10$Ids.Ivt6BADjSHyCOcbNseUgeFmiOAF3hOV3oIOkexaTZ300TqH/2', 17, '2021-01-22 03:44:28', '2021-01-29 06:49:34'),
	(7, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy (8).txt', 'VOIP_jgutierrez - Copy (8)', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24epH6OfHTsU7ZArP2RqwN..Vh.sNxchbMRtNChnn0h.5ZKndxRDeEK', '$2y$10$epH6OfHTsU7ZArP2RqwN..Vh.sNxchbMRtNChnn0h.5ZKndxRDeEK', 17, '2021-01-22 03:44:28', '2021-02-02 00:11:07'),
	(8, 'C:\\Server\\Server 1\\VOIP_jgutierrez - Copy.txt', 'VOIP_jgutierrez - Copy', NULL, '2021-01-19', 96.00, NULL, NULL, 17, '2021-01-22 03:44:28', '2021-01-22 03:44:28'),
	(9, 'C:\\Server\\Server 1\\VOIP_jgutierrez.txt', 'VOIP_jgutierrez', NULL, '2021-01-19', 96.00, 'http://localhost:8000/voip-file/%242y%2410%24io/MxFdpodlRP/H6.JiRXOR2xlz1l9542zZ9lkH8tb8B7m49Y1il.', '$2y$10$2Ac7n1NR8ZbGYJ183dv/xOAPeuyLcFAM30XHj4hR6hxdk9voqRmrK', 17, '2021-01-22 03:44:28', '2021-01-29 06:45:24');
/*!40000 ALTER TABLE `server_file` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`, `created_at`, `updated_at`) VALUES
	(2, 'jgutierrez', '$2y$10$2KBiFQ00E8Z2bAOJLACYF.eQYLNSH2CrvQ90aZUlZ255MGl7YOIiq', 'Jorge', 'Gutierrez', 'jgutierrez4491@gmail.com', NULL, NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table getovpn_db.user_attemps
DROP TABLE IF EXISTS `user_attemps`;
CREATE TABLE IF NOT EXISTS `user_attemps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table getovpn_db.user_attemps: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_attemps` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_attemps` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
